# 🌟 Premium App Catalog

Katalog aplikasi premium — siap order via WhatsApp.

## 🚀 Deploy ke Vercel

1. Login ke GitHub.
2. Buat repository baru bernama `premium-app`.
3. Upload semua file di folder ini (`index.html`, `.gitignore`, `vercel.json`, `README.md`).
4. Buka https://vercel.com/new
5. Pilih repository `premium-app`.
6. Klik **Deploy** — situsmu langsung online!

---

© Renz Store — Ready Premium Apps
